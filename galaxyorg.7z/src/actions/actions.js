export const addTodo = (linkText, linkSrc) => ({
  type: "ADD_TODO",
  payload: {
    linkText,
    linkSrc
  }
});

export const slice_links = (linkText) => ({
  type: "SLICE_LINKS",
  payload: {
    linkText
  }
});
