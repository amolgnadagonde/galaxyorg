const initialState = {
  linkArray: []
};

const todos = (state = initialState, action) => {
  // console.log("todos state", state);
  console.log("action", action);
  switch (action.type) {
    case "ADD_TODO":
      // console.log(action.payload);
      let newArray = state.linkArray.slice(0);
      newArray.push(action.payload);
      // console.log("newArray", newArray);
      state.linkArray = newArray;
      // console.log("state.linkArray", state.linkArray);
      // console.log("state", state);
      return { ...state, linkArray: state.linkArray };
    case "SLICE_LINKS":
      let newAllArray = state.linkArray.slice(0);
      // console.log("newAllArray", newAllArray);
      let clicked_item = action.payload.linkText;
      // console.log('clickedItem', clicked_item);
      let filteredArray = newAllArray.filter((item, index)=>{
        if(item.linkText == clicked_item){
          let newFA = newAllArray.slice(0,(index + 1));
          newAllArray = newFA;
        }
      })
      console.log('fa', newAllArray);
      return { ...state, linkArray: newAllArray };
    default:
      return state;
  }
};

export default todos;
