import { combineReducers } from "redux";
import todos from "./todos";
import slice_link from "./todos";

export default combineReducers({
  todos,
  slice_link
});
