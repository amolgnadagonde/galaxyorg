import React from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import Sidebar from "../Sidebar";
import { addTodo } from "../actions/actions";

function mapStateToProps(state) {
  return {
    linkArray: state.todos.linkArray
  };
}

class Skills extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isloading: true,
      jsonData: null,
      isClicked: false,
      clickedText: null
    };
  }
  componentDidMount() {
    axios
      // .get("/SkillInfo.json")
      .get(`/${this.props.match.params.proId}.json`)
      .then(response => {
        this.setState({
          jsonData: response.data,
          isloading: false
        });
      })
      .catch(error => {
        console.log("error in skills component", error);
      });
  }

  handleClick = (event, linkInfo) => {
    // console.log("linkInfo", linkInfo);
    this.props.dispatch(addTodo(event.target.innerHTML, linkInfo));
  };

  render() {
    let renderingData;

    if (this.state.isloading) {
      renderingData = <div className="loading-icon" />;
    } else {
      const skillItems = this.state.jsonData.skillList.map((item, index) => {
        return (
          <Link
            to={`${this.props.match.url}/${item.skillName}`}
            className="skill-list-item"
            key={index}
            onClick={event => {
              this.handleClick(
                event,
                `${this.props.match.url}/${item.skillName}`
              );
            }}
          >
            {item.skillName}
          </Link>
        );
      });
      renderingData = (
        <div className="skills-container">
          <ul className="skills-list">{skillItems}</ul>
        </div>
      );
    }

    return (
      <div className="skills-container">
        <Sidebar linkArray={this.props.linkArray} linkPath={this.props.match} />
        <div className="skill-list-container">
          <h2 className="page-title">Skills</h2>
          {renderingData}
        </div>
      </div>
    );
  }
}

// export default Skills;
export default connect(mapStateToProps)(Skills);
