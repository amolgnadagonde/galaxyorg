import React from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import { addTodo } from "../actions/actions";

class Organisation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isClicked: false
    };
  }

  render() {
    return (
      <div className="center-container">
        <h2>
          <Link
            to="/projects"
            className="organisation-name"
            onClick={e => {
              this.setState({
                isClicked: !this.state.isClicked
              });
              this.props.dispatch(addTodo(this.props.companyName, "/projects"));
            }}
          >
            {this.props.companyName}
          </Link>
        </h2>
      </div>
    );
  }
}

export default connect()(Organisation);
