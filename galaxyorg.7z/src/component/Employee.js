import React from "react";
import { connect } from "react-redux";

import Sidebar from "../Sidebar";

function mapStateToProps(state) {
  return {
    linkArray: state.todos.linkArray
  };
}

class Employee extends React.Component {
  render() {
    return (
      <div className="skills-container">
        <Sidebar linkArray={this.props.linkArray} />
        <div className="skill-list-container">
          <h2 className="page-title">Employee</h2>
        </div>
      </div>
    );
  }
}

export default connect(mapStateToProps)(Employee);
