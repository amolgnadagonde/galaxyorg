import React from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import { addTodo } from "../actions/actions";

import ReactCSSTransitionGroup from "react-addons-css-transition-group";

import ProjectJSON from "../JSON/ProjectInfo";
import Sidebar from "../Sidebar";

function mapStateToProps(state) {
  return {
    linkArray: state.todos.linkArray
  };
}

class Project extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isClicked: false,
      clickedText: null
    };
  }
  handleClick = (event, linkInfo) => {
    // console.log("linkInfo", linkInfo);
    this.props.dispatch(addTodo(event.target.innerHTML, linkInfo));
  };
  componentWillAppear(){
    console.log('in appear')
  }
  render() {
    // console.log("in project", this.props.match.url);
    const projectItems = ProjectJSON.map((item, index) => {
      return (
        <ReactCSSTransitionGroup
          transitionName="example2"
          transitionAppear={true}
          transitionAppearTimeout={500}
          transitionEnterTimeout={500}
          transitionLeaveTimeout={300}
          key={index}
        >
          <Link
            className="project-list-item"
            onClick={event => {
              this.handleClick(event, `${this.props.match.url}/${item.proId}`);
            }}
            to={`/projects/${item.proId}`}
          >
            {item.proName}
          </Link>
        </ReactCSSTransitionGroup>
      );
    });
    return (
      <div className="project-container">
        <Sidebar linkArray={this.props.linkArray} linkPath={this.props.match} />
        <div className="project-list-container">
          <h2 className="page-title">Projects</h2>
          <ul className="project-list">{projectItems}</ul>
        </div>
      </div>
    );
  }
}

// export default Project;
//https://hackernoon.com/animated-page-transitions-with-react-router-4-reacttransitiongroup-and-animated-1ca17bd97a1a
export default connect(mapStateToProps)(Project);
