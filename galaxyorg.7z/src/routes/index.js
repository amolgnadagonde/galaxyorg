import React from "react";

import Organisation from "../component/Organisation";
import Project from "../component/Project";
import Skills from "../component/Skills";
import Employee from "../component/Employee";

const routes = [
  {
    path: "/",
    exact: true,
    componentToRender: () => <Organisation companyName="Galaxy" />
  },
  { path: "/projects", componentToRender: () => <Project /> },
  {
    path: "/projects/:proId/:skillId",
    exact: true,
    componentToRender: () => <Employee />
  },
  { path: "/projects/:proId", componentToRender: () => <Skills /> }
];

export default routes;

/*
{routes.map(route => {
              console.log(route.path);
              return (
                <Route
                  key={route.path}
                  path={route.path}
                  exact={route.exact}
                  component={route.componentToRender}
                />
              );
            })}
*/
