import React from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import { slice_links } from "./actions/actions";

function mapStateToProps(state) {
  return {
    linkArray: state.todos.linkArray
  };
}

class Sidebar extends React.Component {
  handleClick = event => {
    console.log("in click", this.props.linkArray, event.target.innerHTML);
    this.props.dispatch(slice_links(event.target.innerHTML))
  };
  render() {
    let linkItems = this.props.linkArray.map((item, index) => {
      return (
        <Link
          to={`${item.linkSrc}`}
          key={index}
          onClick={event => {
            this.handleClick(event);
          }}
          className="sidebar-link-items"
        >
          {item.linkText}
        </Link>
      );
    });
    return <div className="sidebar-container"><p>You are here:</p>{linkItems}</div>;
  }
}

export default connect(mapStateToProps)(Sidebar);