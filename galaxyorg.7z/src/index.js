import React from "react";
import ReactDOM from "react-dom";
import { Switch } from "react-router";
import { BrowserRouter as Router, Route } from "react-router-dom";
/* redux */
import { createStore } from "redux";
import { Provider } from "react-redux";
import rootReducer from "./reducers";
/* react transition group */
import ReactCSSTransitionGroup from "react-addons-css-transition-group";
/* other files */
import Organisation from "./component/Organisation";
import Project from "./component/Project";
import Skills from "./component/Skills";
import Employee from "./component/Employee";
/* common routes */
// import routes from "./routes";
/* styles */
import "./styles.css";

const store = createStore(rootReducer);

class App extends React.Component {
  render() {
    // console.log("in app", this.props.match);
    return (
      <ReactCSSTransitionGroup
        transitionName="example"
        transitionAppear={true}
        transitionAppearTimeout={800}
        transitionEnterTimeout={800}
        transitionLeaveTimeout={300}
      >
        <Router>
          <Switch>
            <Route
              exact
              path="/"
              component={() => <Organisation companyName="GalaxyOrg" />}
            />
            <Route exact path="/projects" component={Project} />

            <Route
              exact
              path={`/projects/:proId/:skillId`}
              component={Employee}
            />
            <Route path={`/projects/:proId`} component={Skills} />
          </Switch>
        </Router>
      </ReactCSSTransitionGroup>
    );
  }
}

const rootElement = document.getElementById("root");
ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  rootElement
);

export default App;
